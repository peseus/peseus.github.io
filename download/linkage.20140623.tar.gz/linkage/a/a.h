extern void func_a();
