#include "a.h" 

#include <iostream>

void func_a() {
	std::cout << __FILE__ << ":" << __FUNCTION__ << std::endl;
}
