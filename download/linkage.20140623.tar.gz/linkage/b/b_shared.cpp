#include "b.h" 
#include "a.h"

#include <iostream>

void func_b() {
	std::cout << __FILE__ << ":" << __FUNCTION__ << std::endl;
	std::cout << "caller: " << __FILE__ << ":" << __FUNCTION__ << "|";
	func_a();
}
