extern void func_b();
