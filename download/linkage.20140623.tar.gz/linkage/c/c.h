extern void func_c();
