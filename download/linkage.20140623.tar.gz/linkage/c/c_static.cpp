#include "c.h" 

#include <iostream>

void func_c() {
	std::cout << __FILE__ << ":" << __FUNCTION__ << std::endl;
}
