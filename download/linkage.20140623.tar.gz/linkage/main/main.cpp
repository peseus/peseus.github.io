/**
* author: www.peseus.cn - peseus@qq.com
*/
#include "b.h"

int main(int argc, char* argv[]) {
	func_b();
}
